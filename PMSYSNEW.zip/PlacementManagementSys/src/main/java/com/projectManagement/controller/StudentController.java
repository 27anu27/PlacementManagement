package com.projectManagement.controller;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.projectManagement.model.Company;
import com.projectManagement.model.Student;
import com.projectManagement.services.CompanyService;
import com.projectManagement.services.StudentService;
import com.projectManagement.services.StudentServiceImpl;




@Controller
@RequestMapping(value="/student")
@ComponentScan("com.projectManagement.services")
public class StudentController {
 //Service which will do all data retrieval/manipulation work
    @Autowired
    CompanyService companyService;
    
    @Autowired
    StudentService studentService; 
     
	 
	 
    @RequestMapping(value = "/validate/", method = RequestMethod.POST)
    public ResponseEntity<Void> validate(@RequestBody Student student, HttpServletRequest request) {

    Boolean y= studentService.validateStudent(student);
     if(y==true)
    return new ResponseEntity<Void>(HttpStatus.OK);
     else
    	 return new ResponseEntity<Void>(HttpStatus.CONFLICT);
     
    }
 @RequestMapping(value = "/signUp/", method = RequestMethod.POST)
    public ResponseEntity<Void> createStudent(@RequestBody Student student) {

    	Student currentStudent = studentService.findById(student.getSid());
        if (currentStudent!=null) {
            System.out.println("A Student with name " + student.getSid() + " already exist");
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
 
        studentService.saveStudent(student);
        return new ResponseEntity<Void>( HttpStatus.CREATED);
  
    }
     @RequestMapping(value = "/student/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Student> updatestudent(@PathVariable("id") long id, @RequestBody Student student) {
        System.out.println("Updating student " + id);
         
        Student currentStudent = studentService.findById(id);
         
        if (currentStudent==null) {
            System.out.println("student with id " + id + " not found");
            return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
        }
 
        currentStudent.setName(student.getName());
        currentStudent.setCgpa(student.getCgpa());
        currentStudent.setEmail(student.getEmail());
        currentStudent.setBranch(student.getBranch());
        currentStudent.setPreviousexperience(student.getPreviousexperience()); 
        studentService.updatestudent(currentStudent);
        return new ResponseEntity<Student>(currentStudent, HttpStatus.OK);
    }
    
    
    @RequestMapping(value="/upcomingcompanies",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public  ResponseEntity<List<Company> > upcomingcompanies()
    {
    	List<Company> companies = companyService.upcomingcompanies();
    	
    	if (companies.isEmpty()) {
            return new ResponseEntity<List<Company> >(HttpStatus.NOT_FOUND);
        }
       return new ResponseEntity<List<Company> >(companies, HttpStatus.OK);
    }
    
    
//      @RequestMapping(value="/apply",method=RequestMethod.POST)
//       public ResponseEntity<Void> apply( @RequestParam(value="cid",required=true) String cid,
//    		    @RequestParam(value="sid", required=true) int sid)
//       {
//          companyService.updateapplied(cid,sid);
//          return new ResponseEntity<Void>( HttpStatus.CREATED);
//       
//       }
      
      
//      @RequestMapping(value="/notifications",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//				public  ResponseEntity<List<Company> > notifications()
//				{
//					List<Company> companies = companyService.notifications();
//					
//					if (companies.isEmpty()) {
//				        return new ResponseEntity<List<Company> >(HttpStatus.NOT_FOUND);
//				    }
//				   return new ResponseEntity<List<Company> >(companies, HttpStatus.OK);
//				}

}
    
    
    
    
    
  
    
    
    
    
    
    

 

