package com.projectManagement.controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.projectManagement.model.Company;
import com.projectManagement.model.Student;
import com.projectManagement.services.CompanyService;
import com.projectManagement.services.StudentServiceImpl;

//@RestController
//@RequestMapping(value="/")
public class AdminController {


	@RequestMapping(value = "hello")
    public void check() {
		System.out.println("server");
		 //return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@Autowired
	StudentServiceImpl studentService;  //Service which will do all data retrieval/manipulation work
	@Autowired
	CompanyService companyService;
	@RequestMapping(value = "/validate/", method = RequestMethod.POST)
    public ResponseEntity<Void> validate(@RequestBody Student student) {

         if(student.getPassword().equals("dummypassword"))
        	 return new ResponseEntity<Void>(HttpStatus.OK);
         else
        	 return new ResponseEntity<Void>(HttpStatus.CONFLICT);
}

	@RequestMapping(value = "/addnewcompanies/", method = RequestMethod.POST)
	public ResponseEntity<Void> add(@RequestBody Company company){
		companyService.addCompany(company);
		return new ResponseEntity<Void>(HttpStatus.OK);
		
	}
	
//	@RequestMapping(value = "/updateCompanies/{cid}", method = RequestMethod.POST)
//	public ResponseEntity<Company> update(@PathVariable("cid") String cid,@RequestBody Company company){
//	       Company currentCompany = companyService.getCompanyById(cid);
//	         
//	        if (currentCompany==null) {
//	            return new ResponseEntity<Company>(HttpStatus.NOT_FOUND);
//	        }
//	       
//	        currentCompany.setBranch(company.getBranch());
//	        currentCompany.setArrivaldate(company.getArrivaldate());
//	        currentCompany.setCname(company.getCname());
//	        currentCompany.setLpa(company.getLpa());
//	        currentCompany.setProfile(company.getProfile());
//	         
//	        companyService.updateCompany(currentCompany,cid);
//	        return new ResponseEntity<Company>(currentCompany, HttpStatus.OK);
//	    
//		
//	}
	
	
	
	
	

}








