package com.projectManagement.model;

public class Student {
	private int sid;  
	private String name;  
	private float cgpa;
	private String password;
	private String email;
	private String branch;
	private String previousexperience;
	private String securityanswer;
	
	public String getPreviousexperience() {
		return previousexperience;
	}
	public void setPreviousexperience(String previousexperience) {
		this.previousexperience = previousexperience;
	}
	public String getSecurityanswer() {
		return securityanswer;
	}
	public void setSecurityanswer(String securityanswer) {
		this.securityanswer = securityanswer;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public float getCgpa() {
		return cgpa;
	}
	public void setCgpa(float cgpa) {
		this.cgpa = cgpa;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getId() {
		return sid;
	}
	public void setId(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getcgpa() {
		return cgpa;
	}
	public void setcgpa(float cgpa) {
		this.cgpa = cgpa;
	}
	
	
	
}
