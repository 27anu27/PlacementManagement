package com.projectManagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.projectManagement.model.*;

public class CompanyDao {
	@Autowired
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}  
	public int save(Company c){  
		
		@SuppressWarnings("deprecation")
		String cid=c.getCname()+c.getArrivaldate().getYear();
		
		
	    String sql="insert into Company(cid,cname,lpa,branches,profile,arrivaldate) values("+cid+",'"+c.getCname()+"',"+c.getLpa()+",'"+c.getBranch()+",'"+c.getProfile()+"','"+c.getArrivaldate()+"')";  
	    return template.update(sql);  
	}  
	public int update(Company c){  
	    String sql="update Company set cname='"+c.getCname()+"', lpa="+c.getLpa()+", branch='"+c.getBranch()+", profile='"+c.getProfile()+", where cid="+c.getCid()+" ";  
	    return template.update(sql);
	}    
	 public int placedtable(int sid,int cid,int year,float package1) {
		 String sql="insert into placed(sid,cid,year,package) values("+sid+","+cid+","+year+","+package1+")";
		return template.update(sql); 
	 }
	    
	 public int yearwisedata(String cname,int year) {
		 String cid=cname+year;
		 String sql="select * from placedtable where cid=";
			return template.update(sql);	 
	 }
	 
//	 public List<Company> notification() {
		 
	//	 String sql="";
		// return template.update(sql);
//	 }
	 
	 @SuppressWarnings( "deprecation" )
	 public List<String> getUpCommingCompanyRowMapper(){  
		    Date now=new Date();
		    int present=now.getDate()+now.getMonth()*12;
		    return template.query("select cname from Company where k as (arriavldate.getmonth()*12+arrivaldate.getday()) >="+ present+"",new RowMapper<String>(){  
		       @Override  
		       public String mapRow(ResultSet rs, int rownumber) throws SQLException {  
		   
		           return rs.getString(2);  
		       }  
		       }); 
	 
	    
	}
	
	 
	 @SuppressWarnings( "deprecation" )
	 public List<String> notification(){  
		    Date now=new Date();
		    int present=now.getDate()+now.getMonth()*12;
		    return template.query("select cname from Company where k as (arriavldate.getmonth()*12+arrivaldate.getday()) >="+ present+"",new RowMapper<String>(){  
		       @Override  
		       public String mapRow(ResultSet rs, int rownumber) throws SQLException {  
		   
		           return rs.getString(2);  
		       }  
		       }); 
	 
	    
	}
	 
	 
	 
	 
}

	
