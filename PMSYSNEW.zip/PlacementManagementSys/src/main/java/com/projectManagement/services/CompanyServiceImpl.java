package com.projectManagement.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.projectManagement.dao.CompanyDao;
import com.projectManagement.dao.StudentDao;
import com.projectManagement.model.Company;

public class CompanyServiceImpl implements CompanyService{
	
	ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("springrest-servlet.xml");
	 private StudentDao studentdao = ctx.getBean("studentDao", StudentDao.class);
	 private CompanyDao companydao = ctx.getBean("comapnyDao", CompanyDao.class);
	 

	@Override
	public void addCompany(Company company) {
		companydao.save(company);

	}

	@Override
	public List<Company> upcomingcompanies() {
		
		return null;
		
	}

	@Override
	public void updateCompany(Company company) {
		companydao.update(company);
	}

//	@Override
	//public List<Company> notifications() {
		//List<Company> list=new ArrayList<Company>();
			//	list=companydao.notification();
		
		//return list;
	//s}

	@Override
	public Company getCompanyById(String cid) {

		
		return null;
	}

}
