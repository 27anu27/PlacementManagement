package com.projectManagement.services;

import java.util.List;

import com.projectManagement.model.Company;

public interface CompanyService {
	
	void addCompany(Company company) ;
	
	public List<Company> upcomingcompanies() ;

	public void updateCompany(Company company) ;
	
	///public List<Company> notifications() ;
	
	public Company getCompanyById(String cid) ;


}
