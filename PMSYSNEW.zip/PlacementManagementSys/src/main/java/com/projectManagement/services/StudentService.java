package com.projectManagement.services;

import com.projectManagement.model.Student;

public interface StudentService {
	public void saveStudent(Student x) ;
	
	public boolean validateStudent(Student student);
	
	public Student findById(long id);
	
	public void updatestudent(Student currentStudent);

}
